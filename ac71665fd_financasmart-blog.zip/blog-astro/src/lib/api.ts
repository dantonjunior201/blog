import type { Post, Category } from '../types/blog';

const BASE44_FUNCTION_URL = import.meta.env.BASE44_FUNCTION_URL || 'https://vesper-cd0bd3e2.base44.app/functions';

const DEFAULT_AUTHOR = {
  name: 'Equipe FinançaSmart',
  role: 'Redação FinançaSmart',
  avatar: '',
  bio: 'Equipe dedicada a produzir conteúdo de educação financeira de qualidade para os brasileiros.'
};

function mapToPost(raw: any): Post {
  return {
    id: raw.id,
    slug: raw.slug,
    title: raw.title,
    description: raw.description || raw.metaDescription || '',
    content: raw.content || '',
    coverImage: raw.featuredImage || raw.coverImage || 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?q=80&w=1200&auto=format&fit=crop',
    category: raw.category || 'Finanças Pessoais',
    tags: raw.tags || [],
    author: DEFAULT_AUTHOR,
    publishedAt: raw.publishedAt || new Date().toISOString(),
    readingTimeMinutes: raw.readingTime || raw.readingTimeMinutes || 8,
    featured: false,
    faqs: raw.faqJson || raw.faqs || []
  };
}

export async function getAllPosts(): Promise<Post[]> {
  try {
    const res = await fetch(`${BASE44_FUNCTION_URL}/getPublishedPosts`);
    if (!res.ok) throw new Error(`API error: ${res.status}`);
    const data = await res.json();
    return (data.posts || []).map(mapToPost);
  } catch (error) {
    console.error('Failed to fetch posts:', error);
    return [];
  }
}

export async function getPostBySlug(slug: string): Promise<Post | null> {
  try {
    const res = await fetch(`${BASE44_FUNCTION_URL}/getPostBySlug?slug=${encodeURIComponent(slug)}`);
    if (!res.ok) {
      if (res.status === 404) return null;
      throw new Error(`API error: ${res.status}`);
    }
    const data = await res.json();
    return data.post ? mapToPost(data.post) : null;
  } catch (error) {
    console.error('Failed to fetch post:', error);
    return null;
  }
}

export async function getCategories(posts: Post[]): Promise<Category[]> {
  const categoryMap = new Map<string, number>();
  posts.forEach(post => {
    const cat = post.category || 'Finanças Pessoais';
    categoryMap.set(cat, (categoryMap.get(cat) || 0) + 1);
  });
  return Array.from(categoryMap.entries()).map(([name, count]) => ({
    name,
    slug: name.toLowerCase().replace(/\s+/g, '-'),
    description: `${count} artigo${count > 1 ? 's' : ''}`
  }));
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });
}

export function getReadingTime(content: string): number {
  const text = content.replace(/<[^>]+>/g, '');
  const words = text.split(/\s+/).filter(w => w.length > 0).length;
  return Math.max(1, Math.round(words / 200));
}
