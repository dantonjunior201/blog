import { getAllPosts } from '../lib/api';

export async function GET(context) {
  const posts = await getAllPosts();
  const site = context.site || 'https://financasmart.com.br';
  
  const staticPages = [
    { loc: '/', priority: '1.0', changefreq: 'daily' },
    { loc: '/blog', priority: '0.9', changefreq: 'daily' },
    { loc: '/sobre', priority: '0.5', changefreq: 'monthly' },
    { loc: '/contato', priority: '0.5', changefreq: 'monthly' },
    { loc: '/politica-de-privacidade', priority: '0.3', changefreq: 'yearly' },
    { loc: '/termos-de-uso', priority: '0.3', changefreq: 'yearly' },
    { loc: '/disclaimer', priority: '0.3', changefreq: 'yearly' },
  ];

  const postPages = posts.map(post => ({
    loc: `/blog/${post.slug}/`,
    priority: '0.7',
    changefreq: 'weekly',
    lastmod: post.publishedAt
  }));

  const allPages = [...staticPages, ...postPages];

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allPages.map(page => {
  const url = new URL(page.loc, site).href;
  let entry = `  <url>\n    <loc>${url}</loc>\n    <priority>${page.priority}</priority>\n    <changefreq>${page.changefreq}</changefreq>`;
  if (page.lastmod) {
    entry += `\n    <lastmod>${new Date(page.lastmod).toISOString().split('T')[0]}</lastmod>`;
  }
  entry += `\n  </url>`;
  return entry;
}).join('\n')}
</urlset>`;

  return new Response(sitemap, {
    headers: {
      'Content-Type': 'application/xml'
    }
  });
}
