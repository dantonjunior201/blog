import rss from '@astrojs/rss';
import { getAllPosts } from '../lib/api';

export async function GET(context) {
  const posts = await getAllPosts();
  
  return rss({
    title: 'FinançaSmart',
    description: 'Educação financeira inteligente: investimentos, orçamento, planejamento e independência financeira.',
    site: context.site,
    items: posts.map(post => ({
      title: post.title,
      pubDate: new Date(post.publishedAt),
      description: post.description,
      link: `/blog/${post.slug}/`,
      categories: [post.category, ...post.tags]
    })),
    customData: `<language>pt-BR</language>`,
  });
}
