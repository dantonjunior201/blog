/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />

interface ImportMetaEnv {
  readonly BASE44_API_URL?: string;
  readonly BASE44_APP_ID?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
