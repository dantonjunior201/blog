export interface FAQItem {
  question: string;
  answer: string;
}

export interface Author {
  name: string;
  role?: string;
  avatar?: string;
  bio?: string;
}

export interface Post {
  id: string;
  slug: string;
  title: string;
  description: string;
  content: string; // Markdown or HTML
  coverImage: string;
  category: string;
  tags: string[];
  author: Author;
  publishedAt: string; // ISO date string or YYYY-MM-DD
  updatedAt?: string;
  readingTimeMinutes: number;
  featured?: boolean;
  faqs?: FAQItem[];
}

export interface Category {
  name: string;
  slug: string;
  description?: string;
}
