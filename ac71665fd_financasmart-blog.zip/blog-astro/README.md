# FinançaSmart — Blog Premium de Educação Financeira

Blog Astro otimizado para SEO, Google AdSense e mobile-first com geração automática de conteúdo.

## ✅ O que está pronto

- **5 artigos evergreen** sobre finanças (1600-2000 palavras cada)
- **Geração automática diária** de 5 novos artigos às 9h (workflow Base44)
- **Temas**: Investimentos, Planejamento, Dívidas, Educação Financeira, Independência Financeira
- **SEO completo**: meta tags, JSON-LD, Open Graph, Twitter Cards, Breadcrumbs, Sitemap, RSS
- **Páginas para AdSense**: Sobre, Contato, Política de Privacidade, Termos de Uso, Disclaimer
- **Mobile-first**: design responsivo com Tailwind CSS e dark mode
- **Artigos com**: H1/H2/H3, FAQ, parágrafo em 1ª pessoa, parágrafos de tamanhos variados
- **Imagens em destaque** geradas automaticamente para cada artigo

## 🚀 Como fazer deploy

### Opção 1: Vercel (recomendado)
1. Faça upload da pasta `blog-astro` para um repositório no GitHub
2. Acesse [vercel.com](https://vercel.com) e importe o repositório
3. O Vercel detecta o Astro automaticamente
4. Deploy!

### Opção 2: Netlify
1. Suba o repositório no GitHub
2. Conecte no [netlify.com](https://netlify.com)
3. Build command: `npm run build`
4. Publish directory: `dist`

### Opção 3: GitHub Pages
1. Suba para GitHub
2. Configure GitHub Actions para build do Astro

## ⚙️ Configuração

### Variável de ambiente (opcional)
A API do blog já está configurada por padrão. Se quiser mudar:
```
BASE44_FUNCTION_URL=https://vesper-cd0bd3e2.base44.app/functions
```

### Google AdSense
1. Acesse [adsense.google.com](https://adsense.google.com)
2. Adicione seu site (financasmart.com.br)
3. O site já tem todas as páginas obrigatórias para aprovação
4. Após aprovação, edite o componente `AdSlot.astro` com seu `data-ad-client` e `data-ad-slot`
5. Adicione o script do AdSense no `<head>` do `Base.astro`

### Domínio personalizado
1. Configure o DNS do `financasmart.com.br` para apontar para o Vercel/Netlify
2. Atualize o `site` no `astro.config.mjs` com seu domínio

## 📁 Estrutura do projeto

```
blog-astro/
├── src/
│   ├── components/    # Header, Footer, BlogCard, SEO, FAQ, AdSlot, etc.
│   ├── layouts/       # Base.astro e BlogPostLayout.astro
│   ├── lib/           # api.ts — busca posts da API Base44
│   ├── pages/         # index, blog, sobre, contato, privacidade, termos, etc.
│   ├── styles/        # global.css
│   └── types/         # blog.ts — tipos TypeScript
├── public/            # robots.txt, favicon, manifest
└── astro.config.mjs   # Configuração do Astro
```

## 🔄 Automação diária

O workflow "Blog Posts Diários" roda automaticamente todos os dias às 9h (horário de São Paulo) e:
1. Gera 5 novos artigos de finanças evergreen
2. Cada artigo tem 1600-2000 palavras com H1/H2/H3, FAQ e parágrafo em 1ª pessoa
3. Gera imagens em destaque para cada artigo
4. Salva automaticamente no banco de dados
5. O blog atualiza sozinho no próximo build/deploy

## 🛠️ Comandos

```bash
npm install    # Instalar dependências
npm run dev    # Servidor de desenvolvimento
npm run build  # Build de produção
npm run preview # Preview do build
```
